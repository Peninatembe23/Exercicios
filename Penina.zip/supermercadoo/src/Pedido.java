
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class Pedido {

    private List<ItemPedido> itens;
    private double total;
    private String formaDePagamento;

    public Pedido() {
        itens = new ArrayList<ItemPedido>();
        total = 0;
        formaDePagamento = "";
    }

    public void adicionarItem(ItemPedido item) {
        itens.add(item);
        total += item.getSubtotalotal();
    }

    public List<ItemPedido> getItens() {
        return itens;
    }

    public double getTotal() {
        
        return total;
    }

    public void setFormaDePagamento(String formaDePagamento) {
        this.formaDePagamento = formaDePagamento;
    }

    public String getFormaDePagamento() {
        return formaDePagamento;
    }
}

    

    
    
    
    


