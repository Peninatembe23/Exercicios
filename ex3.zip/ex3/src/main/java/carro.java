/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class carro {
private String modelo;
private int ano;
private String cor;
private int velocidade = 0;
private boolean ligado;

public carro(String modelo, int ano, String cor, int velocidade, boolean ligado){
    this.modelo = modelo;
    this.ano = ano;
    this.cor = cor;
    this.velocidade = velocidade;
    this.ligado = ligado;
}

    public String getModelo() {
        return modelo;
    }

    public int getAno() {
        return ano;
    }

    public String getCor() {
        return cor;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public boolean isLigado() {
        return ligado;
    }

    public int acelerar(){
        this.velocidade += 1;
        
        return this.velocidade;
    }
    
    public int frear(){
        this.velocidade -= 1;
        
        return this.velocidade;
    }
    public void dirigir(){
        System.out.println("Estou sendo dirigido!!!");
    }
    
        public void ligar(){
        System.out.println("Carro Ligado!!!");
    }
        
        public void desligar(){
            this.velocidade = 0;
        System.out.println("Carro desligado!!!");
    }
}  
