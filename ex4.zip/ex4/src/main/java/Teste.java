/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ex4 alunoMatriculado = new ex4("Penina",12,17,14);
        
        double media = alunoMatriculado.calcularMediaFinal();
        
        System.out.println("Media da "+ alunoMatriculado.getNome()+" eh igual: "+media);
    }
    
}
