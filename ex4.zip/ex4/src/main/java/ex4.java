/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class ex4 {
    
    private String nome;
    private double  nota1,nota2,trab,media;

    public ex4(String nome, double nota1, double nota2, double trab) {
        this.nome = nome;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.trab = trab;
    }

    public ex4() {
    }

    public String getNome() {
        return nome;
    }

    public double getNota1() {
        return nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public double getTrab() {
        return trab;
    }

    public double getMedia() {
        return media;
    }
    
    
    
    public double calcularMediaFinal(){
        
        this.media = ((this.nota1 * 0.4)+ (this.nota2 * 0.4))+ (this.trab*0.2);
        
        return this.media;
    }
    
}
