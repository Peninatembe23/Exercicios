/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public abstract class ContaTrasnferivel extends ContaBancaria {

    public ContaTrasnferivel(int numero) {
        super(numero);
    }
}
    

    

