/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class ContaCorrente extends ContaBancaria {
    private double taxaDeOperacao;

    public ContaCorrente(int numero, double taxaDeOperacao) {
        super(numero);
        this.taxaDeOperacao = taxaDeOperacao;
    }

    @Override
    public void depositar(double valor) {
        super.depositar(valor - taxaDeOperacao);
    }

    @Override
    public void sacar(double valor) {
        super.sacar(valor + taxaDeOperacao);
    }

    @Override
    public void mostrarDados() {
        System.out.println("Conta Corrente - Número: " + numero + " | Saldo: " + saldo + " | Taxa de Operação: " + taxaDeOperacao);
    }
}


