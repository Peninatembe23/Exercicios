/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package contabanco;

/**
 *
 * @author TEMBE
 */
public class ContaBanco {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       import java.util.ArrayList;
import java.util.List;

public class Banco implements Imprimivel {
    private List<ContaBancaria> contas = new ArrayList<ContaBancaria>();

    public void inserir(ContaBancaria c) {
        contas.add(c);
    }

    public void remover(ContaBancaria c) {
        contas.remove(c);
    }

    public ContaBancaria procurarConta(int numero) {
        for (ContaBancaria c : contas) {
            if (c.getNumero() == numero) {
                return c;
            }
        }
        return null;
    }

    public List<ContaBancaria> getContas() {
        return contas;
    }

    public void mostrarDados() {
        for (ContaBancaria c : contas) {
            c.mostrarDados();
        }
    }
}
 // TODO code application logic here
    import java.util.ArrayList;
import java.util.List;

public class Banco implements Imprimivel {
    private List<ContaBancaria> contas = new ArrayList<ContaBancaria>();

    public void inserir(ContaBancaria c) {
        contas.add(c);
    }

    public void remover(ContaBancaria c) {
        contas.remove(c);
    }

    public ContaBancaria procurarConta(int numero) {
        for (ContaBancaria c : contas) {
            if (c.getNumero() == numero) {
                return c;
            }
        }
        return null;
    }

    public List<ContaBancaria> getContas() {
        return contas;
    }

    public void mostrarDados() {
        for (ContaBancaria c : contas) {
            c.mostrarDados();
        }
    }
}//BANCOTESTE

    }
import java.util.Scanner;

public class BancoTeste {

    public static void main(String[] args) {
        Banco banco = new Banco();
        Scanner scanner = new Scanner(System.in);

        int opcao = 0;

        while (opcao != 5) {
            System.out.println("Selecione uma opção:");
            System.out.println("1. Criar conta");
            System.out.println("2. Selecionar conta");
            System.out.println("3. Remover conta");
            System.out.println("4. Gerar relatório");
            System.out.println("5. Finalizar");

            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Informe o tipo de conta (1 - Corrente, 2 - Poupança):");
                    int tipo = scanner.nextInt();

                    System.out.println("Informe o número da conta:");
                    int numero = scanner.nextInt();

                    System.out.println("Informe o saldo inicial:");
                    double saldo = scanner.nextDouble();

                    ContaBancaria conta;
                    if (tipo == 1) {
                        conta = new ContaCorrente(numero, saldo);
                    } else {
                        conta = new ContaPoupanca(numero, saldo);
                    }

                    banco.inserir(conta);
                    System.out.println("Conta criada com sucesso!");
                    break;
                case 2:
                    System.out.println("Informe o número da conta:");
                    int numeroConta = scanner.nextInt();

                    ContaBancaria contaSelecionada = banco.procurarConta(numeroConta);

                    if (contaSelecionada == null) {
                        System.out.println("Conta inexistente!");
                    } else {
                        int opcaoConta = 0;

                        while (opcaoConta != 5) {
                            System.out.println("Selecione uma opção:");
                            System.out.println("1. Depositar");
                            System.out.println("2. Sacar");
                            System.out.println("3. Transferir");
                            System.out.println("4. Gerar relatório");
                            System.out.println("5. Retornar ao menu anterior");

                            opcaoConta = scanner.nextInt();

                            switch (opcaoConta) {
                                case 1:
                                    System.out.println("Informe o valor a ser depositado:");
                                    double valorDeposito = scanner.nextDouble();
                                    contaSelecionada.depositar

    
}
