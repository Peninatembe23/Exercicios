/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class ContaPoupanca extends ContaBancaria {
    private double limite;

    public ContaPoupanca(int numero, double limite) {
        super(numero);
        this.limite = limite;
    }

    @Override
    public void sacar(double valor) {
        if (saldo + limite >= valor) {
            super.sacar(valor);
        } else {
            System.out.println("Saldo insuficiente");
        }
    }

    @Override
    public void mostrarDados() {
        System.out.println("Conta Poupança - Número: " + numero + " | Saldo: " + saldo + " | Limite: " + limite);
    }
}
 

