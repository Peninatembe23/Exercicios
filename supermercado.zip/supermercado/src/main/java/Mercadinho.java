
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class Mercadinho {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<produto> produtos = new ArrayList<produto>();
        produtos.add(new produto("Feijao", 30, 40));
        produtos.add(new produto("Batata",25, 40));
        produtos.add(new produto("Amendion", 30,500));
        
        Scanner in = new Scanner (System.in);
       Pedido pedido= new Pedido();
       
        System.out.println("oque deseja visualizar");
        System.out.println("......[1]ver produtos---------");
        System.out.println("----------[2]vender produto");
        
        int opcao=in.nextInt();
        
        switch (opcao){
            case 1:
           
                System.out.println("---Produtos disponiveis----");
                for(produto produto: produtos){
                    System.out.println(produto.getNome()+"-"+produto.getPreco()+"-"+produto.getQuantidade()+"unidades em estoque"); 
                    
                    
                    
                }
                break;
                
            case 2:
                boolean continuarPedido= true;
                while (continuarPedido){
                    System.out.println("Qual priduto deseja comprar");
                    String nomeProduto = in.nextLine();
                    produto  produtoEscolhido = null;
                    for(produto produto: produtos){
                        
                      if(produto.getNome().equalsIgnoreCase(nomeProduto)){
                          produtoEscolhido=produto;
                          break;
                      }  
                    }
                }
        }

        
    }
    
}
