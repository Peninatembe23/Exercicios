/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class Pessoaa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pessoa avoPaterno1=new Pessoa("Tomas", 72);
        Pessoa avoMaterno1=new Pessoa("Albertina", 60);
        Pessoa avoPaterno2=new Pessoa("Rodrigues",80);
        Pessoa avoMaterno2=new Pessoa("Iracema",70);
        Pessoa pai=new Pessoa("Alcina",42,avoPaterno1,avoMaterno1);
        Pessoa mae=new Pessoa("Albino",45,avoPaterno2,avoMaterno2);
        Pessoa filho1=new Pessoa("Kelvin",23,pai,mae);
        Pessoa filha1=new Pessoa("Shanaya",12,pai,mae);
        
        
        
        System.out.println("Arvore genealogica");
        System.out.println("pai:"+pai.getNome()+"idade"+pai.getIdade());
        System.out.println("mae:"+mae.getNome()+"idade"+mae.getIdade());
        System.out.println("filho1:"+filho1.getNome()+"idade"+filho1.getIdade());
        System.out.println("filha1:"+filha1.getNome()+"idade"+filha1.getIdade());
        System.out.println("Avo Paterno:"+pai.getPai().getNome()+"idade"+pai.getPai().getIdade());
        System.out.println("AvO Paterno:"+pai.getPai().getNome()+"idade"+pai.getPai().getIdade());
        System.out.println("Avo Materno:"+mae.getMae().getNome()+"idade"+mae.getMae().getIdade());
        System.out.println("AvO Materno:"+mae.getMae().getNome()+"idade"+mae.getMae().getIdade());






    }
    
}
