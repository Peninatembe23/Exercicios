/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Retangulo r = new Retangulo();
        
        r.setAltura(3);
        r.setBase(20);
      
        double area = r.getArea();
        
        System.out.println("a area e de:" + area);
        
        
    }
    
}
