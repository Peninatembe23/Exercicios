/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TEMBE
 */
public class Retangulo {
   
    double area;
    double base;
    double altura;
    
    public Retangulo(double base, double altura){
       this.base=base;
       this.altura=altura;
        
    }
    public Retangulo(){
        
    }

    
    public double getArea (){
        this.area = altura * base;
        return this.area;
    }

   
    public void setArea(double area){
         this.area=area;
    }
    public double getAtura(){
        return altura;
        
    }
    public void setAltura(double altura){
        this.altura=altura;
    }   
    public double getBase(){
        return base;
       
    }
    public void setBase(double base){
        this.base=base;
    }
    
    }

